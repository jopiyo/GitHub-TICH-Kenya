# 🌍 ClimateGuard Analytics

**AI-powered predictive healthcare readiness for climate-sensitive diseases in East Africa**

[![License: Apache 2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![UNICEF Ventures](https://img.shields.io/badge/UNICEF-Climate%20Ventures%202026-00897B)](https://www.unicef.org/innovation/venturefund)
[![Status: Pilot](https://img.shields.io/badge/Status-Pilot%20Deployment-orange)]()
[![DHIS2 Compatible](https://img.shields.io/badge/DHIS2-Compatible-brightgreen)]()

---

## Overview

ClimateGuard Analytics is an open-source, AI-powered disease surge prediction platform that delivers **4–12 week probabilistic forecasts** of:

- 🦟 **Malaria** surge events
- 🦟 **Dengue fever** outbreaks
- 🌡️ **Heatwave morbidity** surges
- 💨 **Respiratory illness** from wildfire smoke and dust storms

Forecasts are generated at **health facility catchment level**, giving facility managers, county health officers, and community health promoters 28–35 days of advance warning to pre-position medicines, adjust staffing, and prevent stockouts — before surges peak.

ClimateGuard is developed by the **Tropical Institute of Community Health (TICH)** in Nairobi, Kenya, in partnership with **SSRG**, and is built for deployment in low-resource and zero-connectivity settings across East Africa.

---

## The Problem

Climate change is driving unprecedented disease surges across East Africa:

- Malaria cases surged **32%** following the 2023–2024 long rains in Kenya
- Dengue fever cases rose **290%** between 2020–2024
- The 2024 heatwave caused a **47% spike** in paediatric respiratory illness in ASAL counties

Yet health systems remain entirely reactive. Essential medicines stock out in **68% of rural facilities** at least once per quarter, and health workers receive surge guidance **14–21 days after** a surge has already peaked.

ClimateGuard solves this by translating climate signals into actionable, facility-level health intelligence — shifting the system from reactive crisis management to anticipatory care.

---

## How It Works

```
Climate Data (NASA POWER, Copernicus ERA5)
        +
Epidemiological Records (Kenya DHIS2)
        +
Population & Facility Data
        │
        ▼
┌─────────────────────────────────────┐
│     ML Ensemble Model               │
│  • Random Forest (alert triggers)   │
│  • LSTM (12-week surge forecasting) │
│  • XGBoost (heatwave morbidity)     │
│  • Bayesian uncertainty bounds      │
└─────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────┐
│     Output Delivery Layer           │
│  • DHIS2 dashboard (county officers)│
│  • SMS/USSD alerts (CHPs)           │
│  • Android offline (TFLite)         │
└─────────────────────────────────────┘
```

---

## Pilot Results (Kisumu & Kilifi Counties, 2023–2024)

| Metric | Result |
|--------|--------|
| Malaria prediction accuracy | **78% AUC-ROC** |
| Alert lead time advantage | **28–35 days** before surge peak |
| Facilities covered | **14 health facilities** |
| Community health promoters trained | **62 CHPs** using USSD alerts |
| DHIS2 integration | Live — automated weekly data ingestion |
| Offline capability | Fully functional on Android without internet |

---

## Repository Structure

```
ClimateGuard/
├── README.md                   # This file
├── LICENSE                     # Apache 2.0
├── CONTRIBUTING.md             # How to contribute
├── models/
│   ├── README.md               # Model documentation
│   ├── malaria/                # Malaria surge prediction model
│   ├── dengue/                 # Dengue outbreak model
│   ├── heatwave/               # Heatwave morbidity model
│   └── respiratory/            # Respiratory illness model
├── data/
│   ├── README.md               # Data sources and schema
│   ├── schema/                 # Database schema definitions
│   └── sample/                 # Anonymised sample datasets
├── api/
│   ├── README.md               # API documentation
│   └── src/                    # FastAPI backend source
├── dashboard/
│   ├── README.md               # Dashboard documentation
│   └── src/                    # React.js frontend source
├── deployment/
│   ├── README.md               # Deployment guide
│   ├── docker-compose.yml      # Docker deployment
│   └── dhis2-plugin/           # DHIS2 App Hub plugin
└── docs/
    ├── architecture.md         # System architecture
    ├── data-sources.md         # Climate & health data guide
    ├── model-card.md           # Model transparency card
    └── replication-guide.md    # Deploy in your country
```

---

## Quick Start

### Prerequisites
- Docker & Docker Compose
- Python 3.9+
- Node.js 18+
- DHIS2 instance (v2.36+)

### Deploy with Docker

```bash
git clone https://github.com/TICH-Kenya/ClimateGuard.git
cd ClimateGuard
cp deployment/.env.example deployment/.env
# Edit .env with your DHIS2 credentials and API keys
docker-compose -f deployment/docker-compose.yml up -d
```

### Run Models Locally

```bash
cd models
pip install -r requirements.txt
python malaria/predict.py --county kisumu --weeks 12
```

---

## Data Sources

| Source | Data Type | Access |
|--------|-----------|--------|
| [NASA POWER](https://power.larc.nasa.gov/) | Temperature, precipitation, humidity | Free API |
| [Copernicus ERA5](https://cds.climate.copernicus.eu/) | Reanalysis climate data | Free registration |
| [Kenya DHIS2](https://hiskenya.org/) | Disease surveillance records | MOH access required |
| [KNBS](https://www.knbs.or.ke/) | Population & poverty indices | Public |

---

## Replication in Other Countries

ClimateGuard is designed to be deployable in any DHIS2-enabled country within 48 hours. See [`docs/replication-guide.md`](docs/replication-guide.md) for step-by-step instructions for adapting the platform to a new country context.

---

## License

This project is licensed under the **Apache License 2.0** — see the [LICENSE](LICENSE) file for details.

All model weights, training pipelines, and deployment code are openly published and free to use, modify, and distribute.

---

## Developed By

**The Tropical Institute of Community Health (TICH)**
Ngong Road, Nairobi, Kenya
📧 proposals@tich.co.ke
🌐 www.tich.co.ke

In partnership with **SSRG (Sustainable Systems Research Group)**

---

## Acknowledgements

Supported by the **UNICEF Ventures Climate Ventures Fund 2026** and previously seeded by the **GIZ Digital Transformation Centre East Africa**.
