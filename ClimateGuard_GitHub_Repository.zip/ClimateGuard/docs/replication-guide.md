# ClimateGuard Replication Guide

Deploy ClimateGuard in your country in 48 hours.

## Prerequisites

- DHIS2 instance (v2.36+) with disease surveillance data
- Linux server (4 vCPU, 8GB RAM minimum) or cloud VM
- Docker & Docker Compose installed
- NASA POWER API access (free, no key required)
- Copernicus CDS account (free registration at cds.climate.copernicus.eu)

## Step 1: Clone and Configure

```bash
git clone https://github.com/TICH-Kenya/ClimateGuard.git
cd ClimateGuard
cp deployment/.env.example deployment/.env
```

Edit `deployment/.env`:
```
DHIS2_BASE_URL=https://your-dhis2-instance.org
DHIS2_USERNAME=your_username
DHIS2_PASSWORD=your_password
COUNTRY_ISO=KE              # Change to your country ISO code
DISEASE_PROGRAMS=malaria,dengue  # Select applicable modules
```

## Step 2: Map Your DHIS2 Data Elements

Edit `data/schema/dhis2_mapping.json` to match your country's DHIS2 data element UIDs for:
- Confirmed malaria cases (facility level, weekly)
- Dengue / fever cases
- Outpatient attendance
- Health facility coordinates

## Step 3: Deploy

```bash
docker-compose -f deployment/docker-compose.yml up -d
```

This will:
- Start the PostgreSQL + PostGIS database
- Run the initial climate data ingestion (NASA POWER, ERA5)
- Pull your DHIS2 surveillance data
- Train baseline models on your historical data (requires 3+ years of DHIS2 data)
- Launch the FastAPI backend and React dashboard

## Step 4: Validate Models

Before going live, validate model accuracy on held-out data:

```bash
python models/validate.py --country KE --disease malaria --holdout-years 1
```

Review the output AUC-ROC score. We recommend a minimum of 0.70 before using alerts operationally.

## Step 5: Configure Alerts

Edit `deployment/alerts_config.yml`:
```yaml
sms_gateway: africas_talking     # or twilio, or custom
ussd_shortcode: "*XXX#"
alert_threshold: 0.65            # Probability above which alert fires
lead_weeks: 4                    # Minimum weeks ahead to alert
```

## Step 6: Install DHIS2 Plugin

Upload `deployment/dhis2-plugin/climateguard-plugin.zip` to your DHIS2 App Management. The dashboard will appear under Apps once installed.

## Country Adaptations Made So Far

| Country | Status | Notes |
|---------|--------|-------|
| Kenya | ✅ Pilot active | Kisumu & Kilifi counties |
| Uganda | 🔄 Planned | DHIS2 mapping in progress |
| Tanzania | 🔄 Planned | |
| DRC | 🔄 Planned | Goma pilot site identified |

## Getting Help

Open a GitHub Issue or email proposals@tich.co.ke
