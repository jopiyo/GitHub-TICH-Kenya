# ClimateGuard System Architecture

## High-Level Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    DATA INGESTION LAYER                   │
│                                                          │
│  NASA POWER API ──┐                                      │
│  Copernicus ERA5 ─┤──► Climate Feature Pipeline          │
│  KNBS Population ─┘         (Python, weekly cron)        │
│                                                          │
│  Kenya DHIS2 ─────────► Epi Surveillance Pipeline        │
│  (MOH credentials)          (DHIS2 Web API v2.36+)       │
└─────────────────────────────┬────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────┐
│                   ML INFERENCE LAYER                      │
│                                                          │
│  ┌─────────────────┐  ┌──────────────┐  ┌────────────┐  │
│  │  Random Forest  │  │     LSTM     │  │  XGBoost   │  │
│  │ (alert trigger) │  │ (12-wk fcst) │  │ (heatwave) │  │
│  └────────┬────────┘  └──────┬───────┘  └─────┬──────┘  │
│           └──────────────────┴────────────────┘         │
│                              │                           │
│                    Bayesian Uncertainty                  │
│                    Quantification Layer                  │
└─────────────────────────────┬────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────┐
│                   OUTPUT DELIVERY LAYER                   │
│                                                          │
│  ┌──────────────────┐  ┌─────────────┐  ┌────────────┐  │
│  │  DHIS2 Dashboard │  │ SMS / USSD  │  │  Android   │  │
│  │  (React.js)      │  │  Alerts     │  │  Offline   │  │
│  │  County officers │  │  CHPs       │  │  TFLite    │  │
│  └──────────────────┘  └─────────────┘  └────────────┘  │
└──────────────────────────────────────────────────────────┘
```

## Technology Stack

| Component | Technology |
|-----------|-----------|
| ML Models | Python, scikit-learn, TensorFlow, XGBoost |
| Offline Inference | TensorFlow Lite (Android) |
| Data Pipelines | Python, pandas, PostGIS |
| Database | PostgreSQL + PostGIS |
| API | FastAPI (Python) |
| Frontend Dashboard | React.js |
| DHIS2 Integration | DHIS2 Web API, DHIS2 App Hub Plugin |
| SMS/USSD | Africa's Talking API |
| Containerisation | Docker, Docker Compose |
| Version Control | Git / GitHub |
| License | Apache 2.0 |

## Deployment Modes

### Cloud Deployment (County Health Offices)
- Docker Compose on any Linux VM
- Minimum: 4 vCPU, 8GB RAM, 100GB storage
- PostgreSQL database with PostGIS extension
- Weekly automated pipeline via cron jobs

### Offline / Edge Deployment (Health Facilities)
- TFLite model compressed to <50MB
- Runs on Android 8.0+ device (KES ~8,000)
- Local SQLite cache; syncs to central DB on reconnection
- No live internet required for inference

### USSD Delivery (Community Health Promoters)
- Africa's Talking USSD gateway
- Works on any feature phone, any network
- Pulls latest facility-level alert on demand
- No smartphone or data required
