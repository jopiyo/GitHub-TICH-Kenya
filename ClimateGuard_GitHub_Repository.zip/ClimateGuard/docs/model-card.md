# ClimateGuard Model Card

## Model Overview

| Field | Detail |
|-------|--------|
| **Model Name** | ClimateGuard Ensemble v0.1 |
| **Developed By** | TICH (Tropical Institute of Community Health), Nairobi, Kenya |
| **License** | Apache 2.0 |
| **Last Updated** | May 2026 |
| **Status** | Pilot — Kisumu & Kilifi Counties, Kenya |

---

## Models in the Ensemble

### 1. Malaria Surge Classifier (Random Forest)
- **Task:** Binary alert trigger — surge / no surge within 4-week window
- **Features:** 14-day lagged precipitation, mean temperature, NDVI, historical case counts, population density
- **Training data:** DHIS2 Kenya malaria records 2015–2024 + NASA POWER climate data
- **Validation accuracy:** 78% AUC-ROC (held-out 2023–2024 Kisumu data)
- **Alert lead time:** 28–35 days before surge peak

### 2. Surge Magnitude Forecaster (LSTM Neural Network)
- **Task:** 12-week time-series forecasting of case count magnitude
- **Architecture:** 2-layer LSTM, 64 hidden units, dropout 0.2
- **Training data:** Weekly epidemiological time-series 2015–2024
- **Status:** Validated for malaria; dengue and respiratory modules in development

### 3. Heatwave Morbidity Index (XGBoost Regression)
- **Task:** Predict paediatric heat-related morbidity index for upcoming 4 weeks
- **Features:** Max temperature forecast, humidity, air quality index, facility baseline load
- **Status:** In development — validation planned for Turkana County pilot

### 4. Uncertainty Quantification (Bayesian)
- **Task:** Generate calibrated confidence intervals on all predictions
- **Method:** Conformal prediction on held-out calibration set

---

## Known Limitations

- Training data is primarily from Kisumu and Kilifi counties; performance in other geographies requires revalidation
- Dengue, heatwave, and respiratory models are not yet fully validated
- Model accuracy depends on consistent DHIS2 data reporting quality at facility level
- Satellite climate data has ~5km resolution; hyperlocal microclimates may not be captured

---

## Intended Use

ClimateGuard predictions are intended as **decision-support tools** for health system managers. They are not a substitute for clinical judgment or official public health guidance. All alerts should be interpreted alongside local epidemiological knowledge.

---

## Ethical Considerations

- No individual patient data is used; all inputs are aggregated facility-level counts
- Model outputs are probabilistic and include uncertainty bounds to prevent overconfidence
- Community health promoters are trained on appropriate interpretation of alerts
- All training data remains within national DHIS2 infrastructure; no data leaves Kenya
