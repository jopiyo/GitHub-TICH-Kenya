# Contributing to ClimateGuard Analytics

Thank you for your interest in contributing to ClimateGuard! This project is open-source under Apache 2.0 and welcomes contributions from developers, data scientists, public health researchers, and DHIS2 experts worldwide.

## Ways to Contribute

- **Model improvements** — better training data, new disease modules, improved accuracy
- **New country adaptations** — adapting pipelines for Uganda, Tanzania, DRC, Ethiopia
- **DHIS2 plugin development** — extending the App Hub plugin
- **Offline/USSD improvements** — enhancing low-connectivity delivery
- **Documentation** — translations, deployment guides, tutorials
- **Bug reports** — open a GitHub Issue with steps to reproduce

## Getting Started

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature-name`
3. Make your changes with clear, commented code
4. Add or update tests where applicable
5. Submit a Pull Request with a clear description

## Code Standards

- Python: PEP 8, with docstrings on all functions
- JavaScript/React: ESLint with Airbnb config
- All model changes must include updated model card in `docs/model-card.md`
- No personally identifiable health data in any commit

## Reporting Issues

Open a GitHub Issue and include:
- Environment (OS, Python version, DHIS2 version)
- Steps to reproduce
- Expected vs actual behaviour
- Relevant logs

## Contact

For questions about contributing, email: proposals@tich.co.ke
