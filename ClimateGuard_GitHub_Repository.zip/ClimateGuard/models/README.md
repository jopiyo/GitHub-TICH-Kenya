# ClimateGuard Models

This directory contains the machine learning models powering ClimateGuard's disease surge predictions.

## Structure

```
models/
├── requirements.txt        # Python dependencies
├── validate.py             # Model validation script
├── malaria/
│   ├── train.py            # Training pipeline
│   ├── predict.py          # Inference script
│   ├── features.py         # Feature engineering
│   └── README.md
├── dengue/
│   ├── train.py
│   ├── predict.py
│   └── README.md
├── heatwave/
│   ├── train.py
│   ├── predict.py
│   └── README.md
└── respiratory/
    ├── train.py
    ├── predict.py
    └── README.md
```

## Installation

```bash
pip install -r requirements.txt
```

## Requirements

```
scikit-learn>=1.3.0
tensorflow>=2.13.0
xgboost>=1.7.0
pandas>=2.0.0
numpy>=1.24.0
geopandas>=0.13.0
requests>=2.31.0
```

## Running Predictions

```bash
# Malaria surge forecast — Kisumu County, 12-week horizon
python malaria/predict.py --county kisumu --weeks 12

# Output: JSON with weekly surge probability scores + confidence intervals
```

## Model Status

| Module | Status | Validated AUC-ROC | Counties |
|--------|--------|-------------------|---------|
| Malaria | ✅ Active | 0.78 | Kisumu, Kilifi |
| Dengue | 🔄 In development | — | Kilifi (planned) |
| Heatwave | 🔄 In development | — | Turkana (planned) |
| Respiratory | 🔄 In development | — | TBD |

## Model Card

See [`docs/model-card.md`](../docs/model-card.md) for full transparency documentation including training data, known limitations, and ethical considerations.
