"""
ClimateGuard Analytics — Malaria Surge Prediction
Tropical Institute of Community Health (TICH), Nairobi, Kenya
License: Apache 2.0

Predicts malaria surge probability for a given county over a specified forecast horizon.
"""

import argparse
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path

# ---------------------------------------------------------------------------
# Feature Engineering
# ---------------------------------------------------------------------------

def build_climate_features(county: str, forecast_date: datetime, lag_weeks: int = 2) -> pd.DataFrame:
    """
    Fetch and engineer climate features for surge prediction.
    
    In production, this pulls from NASA POWER API and Copernicus ERA5.
    For local/offline use, falls back to cached climate data.
    
    Args:
        county: County name (e.g., 'kisumu', 'kilifi', 'turkana')
        forecast_date: Start date for forecast window
        lag_weeks: Number of lagged weeks to include as features
    
    Returns:
        DataFrame with engineered climate features
    """
    # In production: call climate data pipeline
    # from data.climate_pipeline import fetch_nasa_power, fetch_era5
    
    # Placeholder feature structure matching production schema
    features = {
        "county": county,
        "forecast_date": forecast_date.strftime("%Y-%m-%d"),
        "mean_temp_lag1": None,       # Mean temperature, 1-week lag (°C)
        "mean_temp_lag2": None,       # Mean temperature, 2-week lag (°C)
        "total_precip_lag1": None,    # Total precipitation, 1-week lag (mm)
        "total_precip_lag2": None,    # Total precipitation, 2-week lag (mm)
        "mean_humidity_lag1": None,   # Relative humidity, 1-week lag (%)
        "ndvi_lag2": None,            # NDVI vegetation index, 2-week lag
        "cases_lag1": None,           # Confirmed malaria cases, 1-week lag
        "cases_lag2": None,           # Confirmed malaria cases, 2-week lag
        "cases_lag4": None,           # Confirmed malaria cases, 4-week lag
        "population_density": None,   # Population per km² (KNBS)
        "facility_capacity": None,    # Facility bed capacity index
    }
    
    return pd.DataFrame([features])


def load_model(model_path: Path):
    """
    Load trained Random Forest classifier from disk.
    Falls back to TFLite model for offline/edge deployment.
    """
    try:
        import joblib
        model = joblib.load(model_path / "rf_malaria_classifier.pkl")
        print(f"[ClimateGuard] Loaded Random Forest model from {model_path}")
        return model, "sklearn"
    except FileNotFoundError:
        # Try TFLite for offline/Android deployment
        try:
            import tensorflow as tf
            interpreter = tf.lite.Interpreter(
                model_path=str(model_path / "malaria_model.tflite")
            )
            interpreter.allocate_tensors()
            print("[ClimateGuard] Loaded TFLite model (offline mode)")
            return interpreter, "tflite"
        except Exception as e:
            raise RuntimeError(
                f"No model found at {model_path}. "
                "Download pre-trained weights from the releases page or train a new model with train.py."
            ) from e


# ---------------------------------------------------------------------------
# Prediction
# ---------------------------------------------------------------------------

def predict_surge(county: str, weeks: int = 12, model_dir: str = "weights") -> dict:
    """
    Generate malaria surge probability forecast.
    
    Args:
        county: Target county name
        weeks: Forecast horizon in weeks (default: 12)
        model_dir: Path to trained model weights
    
    Returns:
        Dictionary containing weekly surge probabilities and confidence intervals
    """
    model_path = Path(__file__).parent / model_dir
    model, model_type = load_model(model_path)
    
    results = []
    base_date = datetime.today()
    
    for week in range(1, weeks + 1):
        forecast_date = base_date + timedelta(weeks=week)
        features = build_climate_features(county, forecast_date)
        
        # NOTE: In production, features are populated from live climate + DHIS2 data.
        # This scaffold returns placeholder output for demonstration.
        
        surge_probability = None   # float between 0.0 and 1.0
        confidence_lower = None    # Bayesian 90% lower bound
        confidence_upper = None    # Bayesian 90% upper bound
        alert_triggered = None     # True if surge_probability >= threshold
        
        results.append({
            "week": week,
            "forecast_date": forecast_date.strftime("%Y-%m-%d"),
            "surge_probability": surge_probability,
            "confidence_lower": confidence_lower,
            "confidence_upper": confidence_upper,
            "alert_triggered": alert_triggered,
        })
    
    output = {
        "county": county,
        "disease": "malaria",
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "model_version": "v0.1-pilot",
        "forecast_weeks": weeks,
        "alert_threshold": 0.65,
        "predictions": results,
        "disclaimer": (
            "ClimateGuard predictions are decision-support tools only. "
            "Always interpret alongside local epidemiological knowledge and clinical judgment."
        )
    }
    
    return output


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="ClimateGuard Malaria Surge Predictor"
    )
    parser.add_argument(
        "--county",
        type=str,
        required=True,
        help="Target county (e.g., kisumu, kilifi, turkana)"
    )
    parser.add_argument(
        "--weeks",
        type=int,
        default=12,
        help="Forecast horizon in weeks (default: 12)"
    )
    parser.add_argument(
        "--output",
        type=str,
        default="stdout",
        help="Output path for JSON results, or 'stdout'"
    )
    
    args = parser.parse_args()
    
    print(f"[ClimateGuard] Generating {args.weeks}-week malaria surge forecast for {args.county.title()} County...")
    
    forecast = predict_surge(county=args.county, weeks=args.weeks)
    
    if args.output == "stdout":
        print(json.dumps(forecast, indent=2))
    else:
        with open(args.output, "w") as f:
            json.dump(forecast, f, indent=2)
        print(f"[ClimateGuard] Forecast saved to {args.output}")
