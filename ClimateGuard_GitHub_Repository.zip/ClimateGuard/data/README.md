# ClimateGuard Data Documentation

## Data Sources

| Source | Type | Frequency | Access |
|--------|------|-----------|--------|
| NASA POWER | Climate (temp, precip, humidity) | Daily | Free public API |
| Copernicus ERA5 | Reanalysis climate | Weekly | Free registration |
| Kenya DHIS2 | Disease surveillance | Weekly | MOH credentials required |
| KNBS | Population, poverty | Annual | Public download |
| Sentinel-2 / MODIS | NDVI vegetation index | 16-day | Free via Google Earth Engine |

## Data Schema

### Facility Catchment Table
```sql
CREATE TABLE facility_catchments (
    facility_uid       VARCHAR(11) PRIMARY KEY,  -- DHIS2 UID
    facility_name      TEXT NOT NULL,
    county             TEXT NOT NULL,
    sub_county         TEXT NOT NULL,
    latitude           DECIMAL(9,6),
    longitude          DECIMAL(9,6),
    catchment_pop      INTEGER,
    catchment_geom     GEOMETRY(POLYGON, 4326)
);
```

### Weekly Surveillance Table
```sql
CREATE TABLE weekly_surveillance (
    id                 SERIAL PRIMARY KEY,
    facility_uid       VARCHAR(11) REFERENCES facility_catchments,
    week_start         DATE NOT NULL,
    disease            TEXT NOT NULL,  -- 'malaria', 'dengue', 'respiratory'
    confirmed_cases    INTEGER,
    suspected_cases    INTEGER,
    outpatient_total   INTEGER,
    created_at         TIMESTAMPTZ DEFAULT NOW()
);
```

### Climate Features Table
```sql
CREATE TABLE climate_features (
    id                 SERIAL PRIMARY KEY,
    facility_uid       VARCHAR(11) REFERENCES facility_catchments,
    week_start         DATE NOT NULL,
    mean_temp          DECIMAL(5,2),   -- °C
    max_temp           DECIMAL(5,2),   -- °C
    total_precip       DECIMAL(8,2),   -- mm
    mean_humidity      DECIMAL(5,2),   -- %
    ndvi               DECIMAL(6,4),   -- -1 to 1
    created_at         TIMESTAMPTZ DEFAULT NOW()
);
```

### Predictions Table
```sql
CREATE TABLE surge_predictions (
    id                 SERIAL PRIMARY KEY,
    facility_uid       VARCHAR(11) REFERENCES facility_catchments,
    disease            TEXT NOT NULL,
    generated_at       TIMESTAMPTZ NOT NULL,
    forecast_week      DATE NOT NULL,
    surge_probability  DECIMAL(5,4),   -- 0.0 to 1.0
    conf_lower         DECIMAL(5,4),
    conf_upper         DECIMAL(5,4),
    alert_triggered    BOOLEAN DEFAULT FALSE,
    model_version      TEXT
);
```

## Sample Data

The `sample/` directory contains anonymised, synthetic datasets matching the production schema for development and testing purposes. No real patient data is included.

## Privacy & Data Governance

- All data used by ClimateGuard is **aggregated at facility level** — no individual patient records
- DHIS2 data remains within national infrastructure; ClimateGuard reads via API only
- Climate data is fully public
- No data is transmitted outside Kenya without explicit MOH authorisation
